
export default function Home() {
  return (
    <div className="bg-gradient-to-br from-[#002244] to-[#69BE28] text-white min-h-screen font-sans">
      <!-- conteúdo omitido para brevidade -->
    </div>
  );
}
